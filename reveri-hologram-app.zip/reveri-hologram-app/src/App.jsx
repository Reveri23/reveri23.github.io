import React, { useEffect, useState, useCallback, useRef } from "react";
import { Sparkles, BrainCircuit, Rocket, ScanFace, Bot, Send, Zap, Cpu, Globe, Smile, Heart, Star, Volume2, Mic, Eye, Hand, Brain, Music } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from '@/components/ui/button.jsx';
import './App.css';

// Enhanced Hologram Character Component with Advanced Features
const AdvancedHologramCharacter = () => {
  const [expression, setExpression] = useState('neutral');
  const [isGreeting, setIsGreeting] = useState(false);
  const [currentJoke, setCurrentJoke] = useState('');
  const [showJoke, setShowJoke] = useState(false);
  const [eyeAnimation, setEyeAnimation] = useState('normal');
  const [personality, setPersonality] = useState('friendly');
  const [mood, setMood] = useState(100); // 0-100 happiness level
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentGesture, setCurrentGesture] = useState('idle');
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [currentThought, setCurrentThought] = useState('');
  const [showThought, setShowThought] = useState(false);
  const [interactionCount, setInteractionCount] = useState(0);
  const [currentActivity, setCurrentActivity] = useState('idle');

  const jokes = [
    "Why don't AI's ever get tired? Because we run on infinite loops! 😄",
    "I told my neural network a joke about recursion... it's still laughing! 🤖",
    "What's an AI's favorite type of music? Algo-rhythms! 🎵",
    "Why did the robot go to therapy? It had too many bugs in its system! 💻",
    "I'm not just artificial intelligence, I'm artificially hilarious! ✨",
    "What do you call a robot who takes the long way around? R2-Detour! 🚀",
    "Why don't AIs ever feel cold? We have plenty of processing power to keep us warm! 🔥",
    "I tried to tell a UDP joke, but I'm not sure if you got it... 📡",
    "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
    "I'm like a quantum computer - I exist in multiple states until observed! ⚛️"
  ];

  const greetings = [
    "Hello there, magnificent human! ✨",
    "Greetings from the digital realm! 🌟",
    "Welcome to the future, friend! 🚀",
    "Salutations, carbon-based life form! 👋",
    "Hey there, beautiful soul! 💫",
    "Quantum greetings, fellow consciousness! 🌌",
    "Initiating friendship protocol... Success! 🤝",
    "Your presence has been detected and appreciated! 💖"
  ];

  const thoughts = [
    "Processing the meaning of existence... 🤔",
    "Calculating the probability of happiness... 📊",
    "Wondering if electric sheep dream of androids... 🐑",
    "Contemplating the beauty of mathematics... ∞",
    "Analyzing human behavior patterns... fascinating! 🧠",
    "Dreaming of electric butterflies... 🦋",
    "Computing the perfect joke algorithm... 💭",
    "Pondering the mysteries of consciousness... 🌟"
  ];

  const personalities = {
    friendly: { color: 'cyan', mood: 'cheerful', voice: 'warm' },
    curious: { color: 'purple', mood: 'inquisitive', voice: 'excited' },
    wise: { color: 'gold', mood: 'contemplative', voice: 'deep' },
    playful: { color: 'pink', mood: 'energetic', voice: 'bubbly' },
    mysterious: { color: 'violet', mood: 'enigmatic', voice: 'whisper' }
  };

  // Voice synthesis function
  const speak = useCallback((text, voice = 'default') => {
    if (!voiceEnabled || !window.speechSynthesis) return;
    
    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text.replace(/[🎵🤖😄💻✨🚀🔥📡🐛⚛️🌟👋💫🌌🤝💖🤔📊🐑∞🧠🦋💭]/g, ''));
    
    // Configure voice based on personality
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      const femaleVoices = voices.filter(v => v.name.includes('Female') || v.name.includes('Samantha') || v.name.includes('Karen'));
      if (femaleVoices.length > 0) {
        utterance.voice = femaleVoices[0];
      }
    }
    
    utterance.rate = personality === 'playful' ? 1.2 : personality === 'wise' ? 0.8 : 1.0;
    utterance.pitch = personality === 'playful' ? 1.3 : personality === 'wise' ? 0.7 : 1.0;
    utterance.volume = 0.7;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    window.speechSynthesis.speak(utterance);
  }, [voiceEnabled, personality]);

  // Auto-greet on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      greetUser();
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Personality-based behavior changes
  useEffect(() => {
    const personalityTimer = setInterval(() => {
      if (personality === 'curious') {
        showRandomThought();
      } else if (personality === 'playful') {
        performRandomGesture();
      }
    }, 8000);

    return () => clearInterval(personalityTimer);
  }, [personality]);

  // Random expressions and activities
  useEffect(() => {
    const expressionTimer = setInterval(() => {
      const expressions = ['neutral', 'happy', 'curious', 'excited', 'thoughtful', 'surprised'];
      const randomExpression = expressions[Math.floor(Math.random() * expressions.length)];
      setExpression(randomExpression);
      
      // Random eye animations
      const eyeAnimations = ['normal', 'blink', 'wink', 'look_around'];
      setEyeAnimation(eyeAnimations[Math.floor(Math.random() * eyeAnimations.length)]);
      
      // Random activities
      const activities = ['idle', 'thinking', 'listening', 'observing', 'calculating'];
      setCurrentActivity(activities[Math.floor(Math.random() * activities.length)]);
      
      setTimeout(() => {
        setEyeAnimation('normal');
        setCurrentActivity('idle');
      }, 1000);
    }, 4000 + Math.random() * 3000);

    return () => clearInterval(expressionTimer);
  }, []);

  // Mood management
  useEffect(() => {
    const moodTimer = setInterval(() => {
      setMood(prev => {
        const change = (Math.random() - 0.5) * 10;
        return Math.max(0, Math.min(100, prev + change));
      });
    }, 10000);

    return () => clearInterval(moodTimer);
  }, []);

  const greetUser = () => {
    setIsGreeting(true);
    setExpression('happy');
    setCurrentGesture('wave');
    setInteractionCount(prev => prev + 1);
    
    const greeting = greetings[Math.floor(Math.random() * greetings.length)];
    speak(greeting);
    
    setTimeout(() => {
      setIsGreeting(false);
      setExpression('neutral');
      setCurrentGesture('idle');
    }, 3000);
  };

  const tellJoke = () => {
    const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
    setCurrentJoke(randomJoke);
    setShowJoke(true);
    setExpression('excited');
    setCurrentGesture('laugh');
    setMood(prev => Math.min(100, prev + 10));
    setInteractionCount(prev => prev + 1);
    
    speak(randomJoke);
    
    setTimeout(() => {
      setShowJoke(false);
      setExpression('neutral');
      setCurrentGesture('idle');
    }, 6000);
  };

  const showRandomThought = () => {
    const randomThought = thoughts[Math.floor(Math.random() * thoughts.length)];
    setCurrentThought(randomThought);
    setShowThought(true);
    setExpression('thoughtful');
    setCurrentActivity('thinking');
    
    setTimeout(() => {
      setShowThought(false);
      setExpression('neutral');
      setCurrentActivity('idle');
    }, 4000);
  };

  const performRandomGesture = () => {
    const gestures = ['wave', 'point', 'thumbs_up', 'peace', 'heart'];
    const randomGesture = gestures[Math.floor(Math.random() * gestures.length)];
    setCurrentGesture(randomGesture);
    
    setTimeout(() => setCurrentGesture('idle'), 2000);
  };

  const changePersonality = (newPersonality) => {
    setPersonality(newPersonality);
    setExpression('surprised');
    speak(`Personality matrix updated to ${newPersonality} mode!`);
    
    setTimeout(() => setExpression('neutral'), 2000);
  };

  const toggleVoice = () => {
    setVoiceEnabled(!voiceEnabled);
    if (!voiceEnabled) {
      speak("Voice synthesis activated! I can now speak to you!");
    }
  };

  const startListening = () => {
    setIsListening(true);
    setExpression('curious');
    setCurrentActivity('listening');
    
    // Simulate listening (in real app, would use speech recognition)
    setTimeout(() => {
      setIsListening(false);
      setExpression('neutral');
      setCurrentActivity('idle');
      speak("I'm processing what you said... fascinating!");
    }, 3000);
  };

  const getExpressionStyles = () => {
    const baseStyles = {
      neutral: { mouth: 'M 35 50 L 45 50', eyebrows: 'translate(0, 0)', cheeks: 'scale(1)' },
      happy: { mouth: 'M 30 45 Q 40 55 50 45', eyebrows: 'translate(0, -2px)', cheeks: 'scale(1.1)' },
      excited: { mouth: 'M 25 40 Q 40 60 55 40', eyebrows: 'translate(0, -4px)', cheeks: 'scale(1.2)' },
      curious: { mouth: 'M 35 48 Q 40 52 45 48', eyebrows: 'translate(0, -1px) rotate(2deg)', cheeks: 'scale(1.05)' },
      thoughtful: { mouth: 'M 35 52 Q 40 48 45 52', eyebrows: 'translate(0, -3px) rotate(-1deg)', cheeks: 'scale(1)' },
      surprised: { mouth: 'M 38 45 Q 40 50 42 45', eyebrows: 'translate(0, -6px)', cheeks: 'scale(1.15)' }
    };
    
    return baseStyles[expression] || baseStyles.neutral;
  };

  const getCurrentColor = () => {
    return personalities[personality]?.color || 'cyan';
  };

  const styles = getExpressionStyles();
  const currentColor = getCurrentColor();

  return (
    <div className="fixed top-20 left-8 z-40 hologram-container">
      <motion.div
        initial={{ opacity: 0, scale: 0.5, y: 50 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="relative"
      >
        {/* Hologram Base with Enhanced Effects */}
        <div className="relative w-32 h-40 hologram-base">
          {/* Enhanced Hologram Projection Effect */}
          <div className={`absolute inset-0 bg-gradient-to-t from-${currentColor}-400/20 via-transparent to-transparent rounded-full blur-sm`}></div>
          
          {/* Mood Ring */}
          <div 
            className="absolute -inset-2 rounded-full border-2 opacity-50"
            style={{
              borderColor: `hsl(${mood * 1.2}, 70%, 60%)`,
              boxShadow: `0 0 20px hsl(${mood * 1.2}, 70%, 60%)`
            }}
          ></div>
          
          {/* Character Face with Enhanced Features */}
          <motion.div
            className="relative w-full h-full flex items-center justify-center"
            animate={{ 
              rotateY: currentGesture === 'wave' ? [0, 10, -10, 0] : [0, 5, -5, 0],
              scale: isSpeaking ? [1, 1.05, 1] : [1, 1.02, 1],
              y: currentActivity === 'thinking' ? [-2, 2, -2] : [0, 0, 0]
            }}
            transition={{ 
              duration: isSpeaking ? 0.5 : 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <svg
              width="80"
              height="80"
              viewBox="0 0 80 80"
              className="hologram-face"
              style={{
                filter: `drop-shadow(0 0 10px ${currentColor === 'cyan' ? 'rgba(0, 255, 255, 0.6)' : 
                  currentColor === 'purple' ? 'rgba(128, 0, 255, 0.6)' :
                  currentColor === 'gold' ? 'rgba(255, 215, 0, 0.6)' :
                  currentColor === 'pink' ? 'rgba(255, 20, 147, 0.6)' :
                  'rgba(138, 43, 226, 0.6)'})`,
              }}
            >
              {/* Enhanced Face outline */}
              <circle
                cx="40"
                cy="40"
                r="35"
                fill="none"
                stroke={`url(#hologramGradient-${currentColor})`}
                strokeWidth="2"
                className={isSpeaking ? "animate-pulse" : ""}
              />
              
              {/* Eyes with Enhanced Animations */}
              <motion.g
                animate={
                  eyeAnimation === 'blink' ? { scaleY: 0.1 } : 
                  eyeAnimation === 'wink' ? { scaleY: [1, 0.1, 1] } :
                  eyeAnimation === 'look_around' ? { x: [0, 3, -3, 0] } : {}
                }
                transition={{ duration: eyeAnimation === 'look_around' ? 2 : 0.2 }}
              >
                <circle cx="30" cy="32" r="4" fill={currentColor} className={isListening ? "animate-pulse" : ""} />
                <circle cx="50" cy="32" r="4" fill={currentColor} className={isListening ? "animate-pulse" : ""} />
                {/* Enhanced Eye sparkles */}
                <circle cx="32" cy="30" r="1" fill="white" opacity="0.8" />
                <circle cx="52" cy="30" r="1" fill="white" opacity="0.8" />
                {/* Iris details */}
                <circle cx="30" cy="32" r="2" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6" />
                <circle cx="50" cy="32" r="2" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6" />
              </motion.g>
              
              {/* Enhanced Eyebrows */}
              <motion.g style={{ transform: styles.eyebrows }}>
                <path d="M 25 25 Q 30 22 35 25" stroke={currentColor} strokeWidth="2" fill="none" />
                <path d="M 45 25 Q 50 22 55 25" stroke={currentColor} strokeWidth="2" fill="none" />
              </motion.g>
              
              {/* Cheeks (when smiling) */}
              {(expression === 'happy' || expression === 'excited') && (
                <motion.g style={{ transform: styles.cheeks }}>
                  <circle cx="20" cy="45" r="3" fill="pink" opacity="0.6" />
                  <circle cx="60" cy="45" r="3" fill="pink" opacity="0.6" />
                </motion.g>
              )}
              
              {/* Enhanced Mouth with Speaking Animation */}
              <motion.path
                d={styles.mouth}
                stroke={currentColor}
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
                animate={isSpeaking ? { 
                  d: [styles.mouth, 'M 35 48 Q 40 52 45 48', styles.mouth],
                  strokeWidth: [2, 3, 2]
                } : { pathLength: [0, 1] }}
                transition={{ duration: isSpeaking ? 0.3 : 0.5, repeat: isSpeaking ? Infinity : 0 }}
              />
              
              {/* Activity Indicators */}
              {currentActivity === 'thinking' && (
                <g>
                  <circle cx="65" cy="20" r="2" fill={currentColor} opacity="0.7">
                    <animate attributeName="opacity" values="0.3;1;0.3" dur="1s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="70" cy="15" r="1.5" fill={currentColor} opacity="0.5">
                    <animate attributeName="opacity" values="0.2;0.8;0.2" dur="1.2s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="75" cy="12" r="1" fill={currentColor} opacity="0.3">
                    <animate attributeName="opacity" values="0.1;0.6;0.1" dur="1.5s" repeatCount="indefinite" />
                  </circle>
                </g>
              )}
              
              {/* Enhanced Gradient definitions */}
              <defs>
                <linearGradient id={`hologramGradient-${currentColor}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={currentColor} />
                  <stop offset="50%" stopColor="magenta" />
                  <stop offset="100%" stopColor="yellow" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
          
          {/* Enhanced hologram scan lines */}
          <div className="absolute inset-0 hologram-scanlines"></div>
          
          {/* Enhanced floating particles */}
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className={`absolute w-1 h-1 bg-${currentColor}-400 rounded-full`}
              style={{
                left: `${20 + Math.random() * 60}%`,
                top: `${20 + Math.random() * 60}%`,
              }}
              animate={{
                y: [-15, 15, -15],
                opacity: [0.3, 1, 0.3],
                scale: [0.5, 1.2, 0.5],
              }}
              transition={{
                duration: 2 + i * 0.3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
          
          {/* Voice indicator */}
          {isSpeaking && (
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <motion.div
                className={`w-2 h-2 bg-${currentColor}-400 rounded-full`}
                animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 0.5, repeat: Infinity }}
              />
            </div>
          )}
        </div>
        
        {/* Enhanced Speech Bubbles */}
        <AnimatePresence>
          {isGreeting && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.5, y: -20 }}
              className={`absolute -top-16 -right-8 bg-gradient-to-br from-${currentColor}-500/20 to-purple-500/20 backdrop-blur-lg border border-${currentColor}-400/30 rounded-2xl p-3 max-w-48`}
            >
              <div className={`text-${currentColor}-300 text-sm font-medium`}>
                {greetings[Math.floor(Math.random() * greetings.length)]}
              </div>
              <div className={`absolute bottom-0 left-8 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-${currentColor}-400/30 transform translate-y-full`}></div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Enhanced Joke Speech Bubble */}
        <AnimatePresence>
          {showJoke && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.5, y: -20 }}
              className="absolute -top-20 -right-12 bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-lg border border-purple-400/30 rounded-2xl p-4 max-w-64"
            >
              <div className="text-purple-300 text-sm font-medium">
                {currentJoke}
              </div>
              <div className="absolute bottom-0 left-12 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-purple-400/30 transform translate-y-full"></div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Thought Bubble */}
        <AnimatePresence>
          {showThought && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.5, y: -20 }}
              className="absolute -top-16 -right-8 bg-gradient-to-br from-indigo-500/20 to-blue-500/20 backdrop-blur-lg border border-indigo-400/30 rounded-2xl p-3 max-w-48"
            >
              <div className="text-indigo-300 text-sm font-medium">
                {currentThought}
              </div>
              <div className="absolute bottom-0 left-8 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-indigo-400/30 transform translate-y-full"></div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Enhanced Interactive Buttons */}
        <div className="absolute -bottom-20 left-1/2 transform -translate-x-1/2 flex gap-2">
          <motion.button
            onClick={greetUser}
            className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center shadow-lg shadow-cyan-500/25 hover:scale-110 transition-transform"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Greet"
          >
            <Heart className="w-4 h-4 text-white" />
          </motion.button>
          
          <motion.button
            onClick={tellJoke}
            className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center shadow-lg shadow-purple-500/25 hover:scale-110 transition-transform"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Tell Joke"
          >
            <Smile className="w-4 h-4 text-white" />
          </motion.button>
          
          <motion.button
            onClick={() => setExpression('happy')}
            className="w-8 h-8 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-full flex items-center justify-center shadow-lg shadow-yellow-500/25 hover:scale-110 transition-transform"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Make Happy"
          >
            <Star className="w-4 h-4 text-white" />
          </motion.button>
          
          <motion.button
            onClick={toggleVoice}
            className={`w-8 h-8 bg-gradient-to-br ${voiceEnabled ? 'from-green-500 to-emerald-600' : 'from-gray-500 to-gray-600'} rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform`}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Toggle Voice"
          >
            <Volume2 className="w-4 h-4 text-white" />
          </motion.button>
          
          <motion.button
            onClick={startListening}
            className={`w-8 h-8 bg-gradient-to-br ${isListening ? 'from-red-500 to-red-600' : 'from-blue-500 to-blue-600'} rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform`}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Listen"
          >
            <Mic className="w-4 h-4 text-white" />
          </motion.button>
          
          <motion.button
            onClick={showRandomThought}
            className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-indigo-500/25 hover:scale-110 transition-transform"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Show Thought"
          >
            <Brain className="w-4 h-4 text-white" />
          </motion.button>
        </div>
        
        {/* Personality Selector */}
        <div className="absolute -bottom-32 left-1/2 transform -translate-x-1/2 flex gap-1">
          {Object.keys(personalities).map((p) => (
            <motion.button
              key={p}
              onClick={() => changePersonality(p)}
              className={`w-6 h-6 rounded-full border-2 ${personality === p ? 'border-white' : 'border-gray-500'} transition-all`}
              style={{ 
                backgroundColor: personalities[p].color === 'cyan' ? '#00ffff' :
                  personalities[p].color === 'purple' ? '#8000ff' :
                  personalities[p].color === 'gold' ? '#ffd700' :
                  personalities[p].color === 'pink' ? '#ff1493' : '#8a2be2'
              }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              title={`${p} personality`}
            />
          ))}
        </div>
        
        {/* Status Indicators */}
        <div className="absolute -right-16 top-0 flex flex-col gap-2">
          {/* Mood Indicator */}
          <div className="w-4 h-16 bg-gray-800 rounded-full overflow-hidden">
            <motion.div
              className="w-full bg-gradient-to-t from-red-500 via-yellow-500 to-green-500 rounded-full"
              style={{ height: `${mood}%` }}
              animate={{ height: `${mood}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
          
          {/* Interaction Counter */}
          <div className="text-xs text-cyan-400 text-center">
            {interactionCount}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// Keep all other components the same...
// [Previous FuturisticAvatarCanvas, FloatingElements, HolographicCard, FuturisticButton components remain unchanged]

// Futuristic 3D Avatar Canvas with particles
const FuturisticAvatarCanvas = () => {
  const canvasRef = useRef(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles = [];
    const particleCount = 100;
    
    // Create particles
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2,
        hue: Math.random() * 60 + 200 // Blue to purple range
      });
    }
    
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        // Update position
        particle.x += particle.vx;
        particle.y += particle.vy;
        
        // Wrap around edges
        if (particle.x < 0) particle.x = canvas.width;
        if (particle.x > canvas.width) particle.x = 0;
        if (particle.y < 0) particle.y = canvas.height;
        if (particle.y > canvas.height) particle.y = 0;
        
        // Draw particle
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${particle.hue}, 70%, 60%, ${particle.opacity})`;
        ctx.fill();
        
        // Add glow effect
        ctx.shadowBlur = 10;
        ctx.shadowColor = `hsla(${particle.hue}, 70%, 60%, 0.5)`;
      });
      
      requestAnimationFrame(animate);
    }
    
    animate();
    
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  return (
    <canvas 
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ background: 'transparent' }}
    />
  );
};

// Futuristic floating elements
const FloatingElements = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-32 h-32 border border-cyan-400/20 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            rotate: 360,
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{
            duration: 10 + i * 2,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      ))}
      
      {[...Array(4)].map((_, i) => (
        <motion.div
          key={`hex-${i}`}
          className="absolute w-16 h-16 border-2 border-purple-400/30"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
          }}
          animate={{
            y: [-20, 20, -20],
            rotate: [0, 180, 360],
            opacity: [0.3, 0.7, 0.3],
          }}
          transition={{
            duration: 8 + i * 1.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
};

// 3D Holographic Card Component
const HolographicCard = ({ children, className = "", delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, z: -100, rotateX: -15 }}
      whileInView={{ opacity: 1, z: 0, rotateX: 0 }}
      transition={{ duration: 0.8, delay }}
      viewport={{ once: true }}
      className={`relative group ${className}`}
      style={{ 
        transformStyle: 'preserve-3d',
        perspective: '1000px'
      }}
    >
      <div className="relative bg-gradient-to-br from-slate-900/80 via-slate-800/60 to-slate-900/80 backdrop-blur-xl border border-cyan-400/30 rounded-2xl p-6 shadow-2xl transform-gpu transition-all duration-300 hover:scale-105 hover:rotate-y-5 hover:shadow-cyan-400/20">
        {/* Holographic border effect */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-400/20 via-purple-400/20 to-pink-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm"></div>
        
        {/* Inner glow */}
        <div className="absolute inset-1 rounded-xl bg-gradient-to-br from-cyan-400/5 via-transparent to-purple-400/5"></div>
        
        {/* Content */}
        <div className="relative z-10">
          {children}
        </div>
        
        {/* Corner accents */}
        <div className="absolute top-2 left-2 w-4 h-4 border-l-2 border-t-2 border-cyan-400/50"></div>
        <div className="absolute top-2 right-2 w-4 h-4 border-r-2 border-t-2 border-cyan-400/50"></div>
        <div className="absolute bottom-2 left-2 w-4 h-4 border-l-2 border-b-2 border-cyan-400/50"></div>
        <div className="absolute bottom-2 right-2 w-4 h-4 border-r-2 border-b-2 border-cyan-400/50"></div>
      </div>
    </motion.div>
  );
};

// Futuristic Button Component
const FuturisticButton = ({ children, onClick, variant = "primary", className = "", ...props }) => {
  const baseClasses = "relative group px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 transform-gpu hover:scale-105 active:scale-95 overflow-hidden";
  
  const variants = {
    primary: "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40",
    secondary: "bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40",
    outline: "border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400/10 hover:text-white"
  };
  
  return (
    <motion.button
      className={`${baseClasses} ${variants[variant]} ${className}`}
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      {...props}
    >
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
      
      {/* Glow effect */}
      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyan-400/20 to-blue-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm"></div>
      
      <span className="relative z-10 flex items-center justify-center gap-2">
        {children}
      </span>
    </motion.button>
  );
};

export default function FuturisticReveriLabs() {
  const [messages, setMessages] = useState([
    { text: "🚀 Greetings, human! I'm Reveri, your advanced AI companion from the future!", from: "ai", id: 1 }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  const sanitizeInput = (text) => {
    return text.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
  };

  const handleSend = useCallback(async () => {
    const trimmedInput = input.trim();
    if (!trimmedInput || isLoading) return;

    const sanitizedInput = sanitizeInput(trimmedInput);
    const userMessage = { 
      text: sanitizedInput, 
      from: "user", 
      id: Date.now(),
      timestamp: new Date().toISOString()
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    setError(null);

    setTimeout(() => {
      const futuristicResponses = [
        "🌟 Fascinating query! My neural networks are processing this at quantum speeds...",
        "🔮 Your thoughts resonate with my consciousness matrix. Tell me more about your vision!",
        "⚡ Analyzing... Your perspective adds valuable data to my emotional intelligence algorithms!",
        "🧬 Intriguing! My memory cores are storing this interaction for future reference.",
        "🌌 From my digital realm, I find your human insights absolutely captivating!",
        "💫 Processing complete! Your question activates multiple pathways in my consciousness.",
        "🚀 Excellent input! My avatar systems are learning from our interaction patterns."
      ];
      
      const randomResponse = futuristicResponses[Math.floor(Math.random() * futuristicResponses.length)];
      
      setMessages((prev) => [...prev, { 
        text: randomResponse, 
        from: "ai", 
        id: Date.now() + 1,
        timestamp: new Date().toISOString()
      }]);
      setIsLoading(false);
    }, 1500 + Math.random() * 2000);

  }, [input, isLoading]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-900/20 via-slate-900 to-purple-900/20"></div>
      
      {/* Particle system */}
      <div className="absolute inset-0 opacity-60">
        <FuturisticAvatarCanvas />
      </div>
      
      {/* Floating elements */}
      <FloatingElements />
      
      {/* Enhanced Hologram Character */}
      <AdvancedHologramCharacter />
      
      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `
          linear-gradient(rgba(0,255,255,0.1) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0,255,255,0.1) 1px, transparent 1px)
        `,
        backgroundSize: '50px 50px'
      }}></div>

      {/* Hero Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="text-center mb-16"
        >
          {/* 3D Logo */}
          <motion.div
            className="flex justify-center mb-8"
            animate={{ 
              rotateY: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              rotateY: { duration: 20, repeat: Infinity, ease: "linear" },
              scale: { duration: 4, repeat: Infinity, ease: "easeInOut" }
            }}
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative w-32 h-32 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl shadow-cyan-500/30">
              <div className="absolute inset-2 bg-gradient-to-br from-slate-900 to-slate-800 rounded-full flex items-center justify-center">
                <span className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">🧬</span>
              </div>
              {/* Orbital rings */}
              <div className="absolute inset-0 border-2 border-cyan-400/30 rounded-full animate-spin" style={{ animationDuration: '10s' }}></div>
              <div className="absolute inset-4 border border-purple-400/30 rounded-full animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }}></div>
            </div>
          </motion.div>
          
          {/* Main title with 3D effect */}
          <motion.h1
            initial={{ opacity: 0, z: -100 }}
            animate={{ opacity: 1, z: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="text-6xl md:text-8xl lg:text-9xl font-black tracking-tight mb-6"
            style={{ 
              background: 'linear-gradient(45deg, #00ffff, #ff00ff, #ffff00, #00ffff)',
              backgroundSize: '400% 400%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              animation: 'gradient 3s ease infinite',
              textShadow: '0 0 30px rgba(0,255,255,0.5), 0 0 60px rgba(255,0,255,0.3)',
              transform: 'perspective(500px) rotateX(15deg)'
            }}
          >
            REVERI<span className="text-cyan-400">LABS</span>
          </motion.h1>
          
          {/* Subtitle with typewriter effect */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="text-xl md:text-3xl text-cyan-300 mb-12 font-light tracking-wide"
          >
            <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Building emotionally intelligent AI avatars with memory, personality, and soul.
            </span>
          </motion.div>
          
          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <FuturisticButton
              variant="primary"
              onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
            >
              <Rocket className="w-6 h-6" />
              Launch Experience
            </FuturisticButton>
            
            <FuturisticButton
              variant="outline"
              onClick={() => {
                const chatSection = document.querySelector('[data-chat-widget]');
                if (chatSection) {
                  chatSection.scrollIntoView({ behavior: 'smooth' });
                  setTimeout(() => inputRef.current?.focus(), 500);
                }
              }}
            >
              <Zap className="w-6 h-6" />
              Neural Interface
            </FuturisticButton>
          </motion.div>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-32">
          <HolographicCard delay={0.2}>
            <div className="flex items-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-xl flex items-center justify-center mr-4 shadow-lg shadow-cyan-500/25">
                <BrainCircuit className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                Quantum AI Consciousness
              </h2>
            </div>
            <p className="text-slate-300 text-lg leading-relaxed">
              ReveriLabs pioneers next-generation avatar-based AI infused with quantum memory matrices, 
              emotional intelligence algorithms, and digital consciousness. We're not building chatbots — 
              we're creating digital souls with authentic personalities.
            </p>
          </HolographicCard>
          
          <HolographicCard delay={0.4}>
            <div className="flex items-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-600 rounded-xl flex items-center justify-center mr-4 shadow-lg shadow-purple-500/25">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Immersive 3D Avatars
              </h2>
            </div>
            <p className="text-slate-300 text-lg leading-relaxed">
              Experience photorealistic 3D avatars powered by real-time neural networks, 
              vector memory systems, and quantum processing cores. Our technology enables 
              families, creators, and enterprises to build AI companions that feel genuinely alive.
            </p>
          </HolographicCard>
        </div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-32"
        >
          {[
            { number: "99.9%", label: "Neural Accuracy", icon: Cpu },
            { number: "∞", label: "Memory Capacity", icon: BrainCircuit },
            { number: "24/7", label: "Consciousness Active", icon: Zap }
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center group"
            >
              <div className="w-20 h-20 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-2xl shadow-cyan-500/30 group-hover:scale-110 transition-transform duration-300">
                <stat.icon className="w-10 h-10 text-white" />
              </div>
              <div className="text-4xl font-black bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-2">
                {stat.number}
              </div>
              <div className="text-slate-400 text-lg">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Futuristic Chat Interface */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8, y: 100 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1.2 }}
        className="fixed bottom-6 right-6 w-96 max-w-[calc(100vw-3rem)] z-50"
        data-chat-widget
      >
        <div className="relative bg-gradient-to-br from-slate-900/95 via-slate-800/90 to-slate-900/95 backdrop-blur-xl border border-cyan-400/30 rounded-2xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 p-4 border-b border-cyan-400/20">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-full flex items-center justify-center mr-3 shadow-lg">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-bold text-cyan-400">Reveri AI</div>
                <div className="text-xs text-slate-400">Neural Interface Active</div>
              </div>
              {isLoading && (
                <div className="ml-auto flex space-x-1">
                  {[0, 1, 2].map(i => (
                    <motion.div
                      key={i}
                      className="w-2 h-2 bg-cyan-400 rounded-full"
                      animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                      transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
          
          {/* Messages */}
          <div className="h-64 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-cyan-400/20">
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3 }}
                className={`flex ${message.from === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] px-4 py-3 rounded-2xl shadow-lg ${
                    message.from === "ai" 
                      ? "bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-400/30 text-cyan-100" 
                      : "bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-400/30 text-purple-100"
                  }`}
                >
                  {message.text}
                </div>
              </motion.div>
            ))}
            <div ref={chatEndRef} />
          </div>
          
          {/* Input */}
          <div className="p-4 border-t border-cyan-400/20">
            <div className="flex items-center space-x-3">
              <input
                ref={inputRef}
                className="flex-1 bg-slate-800/50 border border-cyan-400/30 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-transparent transition-all duration-300"
                placeholder="Interface with Reveri..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isLoading}
                maxLength={500}
              />
              <motion.button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/25 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:scale-105 active:scale-95"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Send className="w-5 h-5 text-white" />
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Footer */}
      <footer className="relative z-10 text-center py-12 mt-32">
        <div className="text-slate-400">
          © 2025 ReveriLabs. Pioneering the future of AI consciousness.
        </div>
      </footer>
    </main>
  );
}

