# ReveriLabs Advanced Hologram Web Application

## 🚀 Features

This is an advanced futuristic web application featuring an interactive hologram character with:

### 🤖 Hologram Character Features:
- **Interactive holographic face** with animated expressions
- **Voice synthesis** with personality-based modulation
- **5 distinct personalities** (Friendly, Curious, Wise, Playful, Mysterious)
- **Advanced expressions** (Happy, Excited, Curious, Thoughtful, Surprised)
- **Gesture system** (Wave, Point, Thumbs up, Peace, Heart)
- **Thought bubbles** with AI philosophical musings
- **Mood tracking** with visual mood meter
- **Listening mode** with active feedback
- **Speech bubbles** for greetings and jokes

### 🎨 Visual Effects:
- **3D holographic projections** with scan lines
- **Particle systems** and floating elements
- **Personality-based color schemes**
- **Advanced CSS animations**
- **Responsive futuristic design**
- **Cyberpunk aesthetic** with neon effects

### 🎮 Interactive Controls:
- **6 action buttons**: Greet, Tell Joke, Make Happy, Toggle Voice, Listen, Show Thought
- **5 personality buttons**: Switch between different AI personalities
- **Voice synthesis toggle** with Web Speech API
- **Real-time mood and interaction tracking**

## 🛠️ Installation & Setup

### Prerequisites:
- Node.js (v18 or higher)
- npm or pnpm

### Installation:
```bash
# Install dependencies
npm install
# or
pnpm install

# Start development server
npm run dev
# or
pnpm run dev
```

### Build for Production:
```bash
npm run build
# or
pnpm run build
```

## 🎯 Usage

1. **Enable Voice**: Click the voice button (turns green when active)
2. **Change Personality**: Click any of the 5 colored personality buttons
3. **Interact**: Use the action buttons to see different behaviors
4. **Watch Animations**: Observe automatic expressions and mood changes
5. **Listen to Voice**: Hear personality-based voice responses

## 🔧 Technical Details

- **Framework**: React 18 with Vite
- **Styling**: Tailwind CSS with custom animations
- **Icons**: Lucide React
- **Animations**: Framer Motion
- **Voice**: Web Speech API
- **Responsive**: Mobile-friendly design

## 🎨 Customization

### Adding New Personalities:
Edit the `personalities` object in `App.jsx` to add new personality types with custom colors and behaviors.

### Modifying Expressions:
Update the `getExpressionStyles()` function to add new facial expressions and animations.

### Adding Voice Features:
Extend the `speak()` function to add more voice customization options.

## 📱 Browser Compatibility

- Chrome/Edge: Full support including voice synthesis
- Firefox: Visual features supported, limited voice support
- Safari: Most features supported
- Mobile browsers: Responsive design with touch support

## 🌟 Credits

Created with advanced AI assistance featuring:
- Interactive hologram character design
- Futuristic UI/UX with cyberpunk aesthetics
- Advanced animation systems
- Voice synthesis integration
- Personality-based AI behaviors

Enjoy your futuristic AI companion! 🤖✨

